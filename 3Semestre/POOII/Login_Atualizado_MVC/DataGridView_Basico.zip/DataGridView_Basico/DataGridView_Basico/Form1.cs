﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataGridView_Basico
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int _linhaIndice;

        private void Form1_Load(object sender, EventArgs e)
        {
            CarregaDados();
        }

        private void dgvAlunos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Retorna o indice da linha no qual a célula foi clicada
            _linhaIndice = e.RowIndex;  

            //Se _linhaIndice é menor que -1 então retorna
            if (_linhaIndice == -1)
            { 
                return;
            }
            
            //Cria um objeto DataGridViewRow de um indice particular
            DataGridViewRow rowData = dgvAlunos.Rows[_linhaIndice]; 

            //exibe os valores no textbox
            txtCodigo.Text = rowData.Cells[0].Value.ToString();
            txtNome.Text = rowData.Cells[1].Value.ToString();
            txtEmail.Text = rowData.Cells[2].Value.ToString();
            txtCurso.Text = rowData.Cells[3].Value.ToString();
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            if (btnIncluir.Text == "Incluir")
            {
                limpaTextBox();
                btnIncluir.Text = "Salvar";
                txtNome.Focus();
            }
            else
            {
                btnIncluir.Text = "Incluir";
                SqlParameter[] arParms = new SqlParameter[3];
                arParms[0] = new SqlParameter("@Nome", txtNome.Text);
                arParms[1] = new SqlParameter("@Email", txtEmail.Text);
                arParms[2] = new SqlParameter("@Curso", txtCurso.Text);
                string sql = "Insert Into Alunos(nome,email,curso) values(@Nome,@Email,@Curso)";

                try
                {
                    int i = DAL.SQLHelper.ExecuteNonQuery(DAL.SQLHelper.conection, sql, CommandType.Text, arParms);
                    CarregaDados();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" Erro :: " + ex.Message);
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dgvAlunos.Rows.Count <= 0)
            {
                MessageBox.Show("Não existem dados a excluir.");
                return;
            }
            //verifica se foi selecionado um registro
            if (string.IsNullOrEmpty(txtCodigo.Text) || string.IsNullOrEmpty(txtNome.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtCurso.Text))
            {
                MessageBox.Show("Selecione um registro para exclusão.");
                return;
            }

            //Se rowindex é menor que um retorna pois seleção foi inválida
            if (_linhaIndice < 0)
                return;

            if (!(MessageBox.Show("Confirma a exclusão deste registro?", "Excluir registro !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes))
                return;

            //define os parametros
            SqlParameter[] arParms = new SqlParameter[1];
            arParms[0] = new SqlParameter("@Codigo", Convert.ToInt32(txtCodigo.Text));
            string sql = "Delete from Alunos Where Id = @codigo";

            try
            {
                int i = DAL.SQLHelper.ExecuteNonQuery(DAL.SQLHelper.conection, sql, CommandType.Text, arParms);
                CarregaDados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Erro :: " + ex.Message);
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (dgvAlunos.Rows.Count <= 0)
            {
                MessageBox.Show("Não existem dados a excluir.");
                return;
            }
            //verifica se foi selecionado um registro
            if (string.IsNullOrEmpty(txtCodigo.Text) || string.IsNullOrEmpty(txtNome.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtCurso.Text))
            {
                MessageBox.Show("Selecione um registro para exclusão.");
                return;
            }

            //Se rowindex é menor que um retorna pois seleção foi inválida
            if (_linhaIndice < 0)
                return;

            if (!(MessageBox.Show("Confirma a atualização deste registro?", "Atualizar registro !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes))
                return;

            SqlParameter[] arParms = new SqlParameter[4];
            arParms[0] = new SqlParameter("@Nome", txtNome.Text);
            arParms[1] = new SqlParameter("@Email", txtEmail.Text);
            arParms[2] = new SqlParameter("@Curso", txtCurso.Text);
            arParms[3] = new SqlParameter("@Codigo", txtCodigo.Text);
            string sql = "Update Alunos set Nome=@Nome, Email=@Email, Curso=@Curso Where Id=@Codigo";

            try
            {
                int i = DAL.SQLHelper.ExecuteNonQuery(DAL.SQLHelper.conection, sql, CommandType.Text, arParms);
                CarregaDados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Erro :: " + ex.Message);
            }

        }
        
        private void limpaTextBox()
        {
            TextBox[] tempTextBox = { txtCodigo, txtNome, txtEmail, txtCurso };
            foreach (TextBox temp in tempTextBox)
                temp.Clear();
        }

        private void CarregaDados()
        {
            try
            {
                dgvAlunos.DataSource = DAL.SQLHelper.ExecuteDataTable(DAL.SQLHelper.conection, "Select * from Alunos", CommandType.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEncerrar_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }
    }
}
