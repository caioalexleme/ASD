#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<locale.h> //necess�rio para usar setlocale
#include<string.h> //necess�rio para strcmp
#include<time.h> //necess�rio para usar localtime() e struct tm
#define SIZE 200

char option;
int cadastro();
int grupos_de_risco();
int grupo_com_comorbidade();
int grupo_sem_risco();
int pesquisa();
int lista();
int login();
int ano;
int mostrar();

typedef struct CADASTRO cadastro2; //redefinindo a struct para encurtar o comando na declara��o
struct CADASTRO{
char nome[50];
char cpf[12];
char email[20];
long fone;
char rua[40];
char numero[10];
char cidade[30];
char estado[20];
char cep[9];
int nascimento;
int ano;
int confirma;

char comorbidade[20];
int data;
int mes;
int dia;
int hora;
int minutos;
int segundos;

};


int op;
int linha=0;


struct{

    char nome[50];
    char login[20];
    char senha[16];
} usuarios[10];


int i;

int main (){

    system("color C");
    setlocale(LC_ALL, "portuguese");

    strcpy(usuarios[0].nome, "admin");
    strcpy(usuarios[0].login, "admin");
    strcpy(usuarios[0].senha, "1234");
    while(login()==0);

    do{

       system("cls"); // limpa a tela de sa�da

       printf("\t\t-------------MENU PRINCIPAL--------------\t\t");
       printf("\t\n-------------------------------------------------------------------\t\n");

       printf("\t\n#--------------------------------------------#\t\n");
       printf("\t\n|[1] - CADASTRAR                               |\t\n");
       printf("\t\n|[2] - PESQUISAR POR PACIENTES CADASTRADOS     |\t\n");
       printf("\t\n|[3] - GRUPOS DE PACIENTES                     |\t\n");
       printf("\t\n|[4] - SAIR                                    |\t\n");
       printf("\t\n#--------------------------------------------#\t\n");
       printf("\t\n Selecione a Op��o Desejada: ");
       op=getch();

            switch(op){

            case '1':
                cadastro();

                break; //for�a a sa�da imediata do loop

            case '2':
                pesquisa();

                break;

            case '3':
                lista();

                break;

            case '4':

                break;

            default:
                printf("Op��o Inv�lida!\n");
                break;

            }

    }while(op!='4');


    system("cls");
    printf("\t\t\t SAINDO DO SISTEMA!!! \n");

   system("pause");
}


int cadastro(){
  int pessoa;

FILE* arquivo; //ponteiro para o arquivo
cadastro2 add;

arquivo = fopen("Paciente.txt","ab"); //abrindo o arquivo com tipo de abertura ab

if(arquivo == NULL){ //testando se o arquivo foi aberto com sucesso
    printf("Problemas Na Abertura");

}

else {

 struct tm *data_hora_atual; //ponteiro para struct que armazena data e hora
        time_t segundos;    //vari�vel do tipo time_t para armazenar o tempo em segundos
        time(&segundos);
        data_hora_atual = localtime(&segundos);
        data_hora_atual->tm_hour;
        data_hora_atual->tm_min;
        data_hora_atual->tm_sec;
        data_hora_atual->tm_mday;
        data_hora_atual->tm_mon+1;
        add.ano = data_hora_atual->tm_year+1900;//ano//





    do{
        system("cls");
        printf("\t\t----------CADASTRAMENTO DE PACIENTES--------\t\n");
        printf("\t\t|------------------------------------------|\n\n");

        fflush(stdin);
        printf("\nNome: ");
        gets(add.nome);
        fflush(stdin);
        printf("\nCPF: ");
        gets(add.cpf);
        fflush(stdin);
        printf("\nEmail: ");
        gets(add.email);
        fflush(stdin);
        printf("\nTelefone: ");
        scanf("%d", &add.fone);
        fflush(stdin);
        printf("\nRua e Bairro: ");
        gets(add.rua);
        fflush(stdin);
        printf("\nN�mero: ");
        gets(add.numero);
        fflush(stdin);
        printf("\nCidade: ");
        gets(add.cidade);
        fflush(stdin);
        printf("\nEstado: ");
        gets(add.estado);
        fflush(stdin);
        printf("\nCEP: ");
        gets(add.cep);
        fflush(stdin);
        printf("\nAno de Nascimento: ");
        scanf("%d", &pessoa);
        add.nascimento = add.ano - pessoa;
        fflush(stdin);
        printf("%d", add.nascimento);
        printf("\nO Paciente Possui Comorbidade? Digite (S)Sim ou (N)N�o: ");

        option = toupper (getch());

        if(option == 'S'){

           fflush(stdin);
           printf("\nTipo de comorbidade: ");
           gets(add.comorbidade);
           add.confirma = 1; // Confirma que o paciente tem comorbidade
        }
        else{
            add.confirma = 3; // Pacienete fora do grupo comorbidade
        }

        fflush(stdin);

        printf("\n\n");
        printf("Dados do Paciente Salvos!\n\n");

        printf("-------------------------------\n");
        printf("1 - Tentar Novamente           \n");
        printf("2 - Finalizar Cadastro         \n");
        printf("-------------------------------\n");

       fwrite(&add,sizeof(cadastro2),1,arquivo);

        printf("Op��o Escolhida: ");
        scanf("%d", &op);


   } while(op != 2);

  fclose(arquivo); //usando fclose para fechar o arquivo


       if(add.nascimento >= 66 ){ //condi��o para decidir se o paciente tem idade maior ou igual a 66 anos

         FILE *dados;

        dados=fopen("Risco.txt","a"); //abrindo o arquivo
        fprintf(dados,"CEP: %s\n",add.cep);
        fprintf(dados,"Idade: %d\n\n\n",add.nascimento);
        fclose(dados); // fechando arquivo

        }

}

}

int pesquisa(){
     system("cls");
     FILE* arquivo; //ponteiro para o arquivo
     cadastro2 add;
     char cpfpaciente[50];

     arquivo = fopen("Paciente.txt", "rb"); //abrindo o arquivo com tipo de abertura rb(leitura)
     if(arquivo == NULL){ //testando se o arquivo foi realmente criado
        printf("Problemas na Abertura");

     }else{
        fflush(stdin);
        printf("Digite o CPF: ");
        gets(cpfpaciente);

     while(fread(&add, sizeof(cadastro2), 1,arquivo)==1){ //fread - L� um arquivo bin�rio
        if(strcmp(cpfpaciente, add.cpf)==0){
        if(add.nascimento <= 65  && add.confirma <=1){



         printf("\t\t-------GRUPO COM COMORBIDADE-------\t\n");
         printf("\t\t-----------------------------------\n\n");
         printf("------------------------------------\n");
         printf("Nome: %s\n", add.nome);
         printf("CPF: %s\n", add.cpf);
         printf("Email: %s\n", add.email);
         printf("Fone: %d\n", add.fone);
         printf("Rua: %s\n", add.rua);
         printf("N�mero: %s\n", add.numero);
         printf("Cidade: %s\n", add.cidade);
         printf("Estado: %s\n", add.estado);
         printf("CEP: %s\n", add.cep);
         printf("Nascimento: %d\n", add.nascimento);

        }
       if(add.nascimento <= 65 && add.confirma >=3){



         printf("\t\t-------GRUPO SEM RISCO-------\t\n");
         printf("\t\t------------------------------\n\n");
         printf("------------------------------------\n");

         printf("Nome: %s\n", add.nome);
         printf("CPF: %s\n", add.cpf);
         printf("Email: %s\n", add.email);
         printf("Fone: %d\n", add.fone);
         printf("Rua: %s\n", add.rua);
         printf("N�mero: %s\n", add.numero);
         printf("Cidade: %s\n", add.cidade);
         printf("Estado: %s\n", add.estado);
         printf("CEP: %s\n", add.cep);
         printf("Idade: %d\n", add.nascimento);

       }
          if(add.nascimento > 65 && add.confirma>=0){


         printf("\t\t-------GRUPO DE RISCO-------\t\n");
         printf("\t\t------------------------------\n\n");
         printf("------------------------------------\n");

         printf("Nome: %s\n", add.nome);
         printf("CPF: %s\n", add.cpf);
         printf("Email: %s\n", add.email);
         printf("Fone: %d\n", add.fone);
         printf("Rua: %s\n", add.rua);
         printf("N�mero: %s\n", add.numero);
         printf("Cidade: %s\n", add.cidade);
         printf("Estado: %s\n", add.estado);
         printf("CEP: %s\n", add.cep);
         printf("Idade: %d\n", add.nascimento);

     }

     fclose(arquivo); // fechando arquivo
     system("pause"); //pausa na tela, somente para Windows
     }
     }

     }
     }


int lista(){


    system("cls");
    printf("\t\t---------GRUPO DE PACIENTES CADASTRADOS NO SISTEMA-------\t\n");
    printf("\t\t|-------------------------------------------------------|\n\n");

        printf("\n[1] - Grupo De Risco\n\n");
        printf("\n[2] - Grupo Com Comorbidade\n\n");
        printf("\n[3] - Grupo Sem Risco\n\n");

        printf("Op��o Desejada: ");
        scanf("%d", &op);
        system("cls");

        switch(op){

            case 1:
               grupos_de_risco();

              break;

            case 2:
                grupo_com_comorbidade();

                break;

            case 3:
                grupo_sem_risco();

                break;

            default:
                printf("Op��o Inv�lida!\n");

                break;

            }

            printf("\n--------------------------------\n");
            printf("1 - Voltar Ao Menu Principal     |\n");
            printf("--------------------------------\n");
            printf("Selecione a Op��o Desejada: ");
            scanf("%d", &op);


    return 0;
}

int grupos_de_risco(){

     system("cls");
     FILE* arquivo; //ponteiro para o arquivo
     cadastro2 add;


     arquivo = fopen("Paciente.txt", "rb"); //abrindo o arquivo com tipo de abertura rb(leitura)
     if(arquivo == NULL){  //testando se o arquivo foi realmente criado
        printf("Problemas na Abertura");

     }
     else{
        fflush(stdin);



     while(fread(&add, sizeof(cadastro2), 1,arquivo)==1){ //fread - L� um arquivo bin�rio
            if(add.nascimento > 65 && add.confirma>=0){


         printf("\t\t-------GRUPO DE RISCO-------\t\n");
         printf("\t\t------------------------------\n\n");
         printf("------------------------------------\n");

         printf("Nome: %s\n", add.nome);
         printf("CPF: %s\n", add.cpf);
         printf("Email: %s\n", add.email);
         printf("Fone: %d\n", add.fone);
         printf("Rua: %s\n", add.rua);
         printf("N�mero: %s\n", add.numero);
         printf("Cidade: %s\n", add.cidade);
         printf("Estado: %s\n", add.estado);
         printf("CEP: %s\n", add.cep);
         printf("Idade: %d\n", add.nascimento);

     }
     }
     }
     fclose(arquivo);

}
int grupo_com_comorbidade(){

     system("cls");
     FILE* arquivo; //ponteiro para o arquivo
     cadastro2 add;


     arquivo = fopen("Paciente.txt", "rb"); //abrindo o arquivo com tipo de abertura rb(leitura)
     if(arquivo == NULL){  //testando se o arquivo foi realmente criado
        printf("Problemas na Abertura");

     }
     else{
        fflush(stdin);



     while(fread(&add, sizeof(cadastro2), 1,arquivo)==1){ //fread - L� um arquivo bin�rio
        if(add.nascimento <= 65  && add.confirma <=1){



         printf("\t\t-------GRUPO COM COMORBIDADE-------\t\n");
         printf("\t\t-----------------------------------\n\n");


         printf("Nome: %s\n", add.nome);
         printf("CPF: %s\n", add.cpf);
         printf("Email: %s\n", add.email);
         printf("Fone: %d\n", add.fone);
         printf("Rua: %s\n", add.rua);
         printf("N�mero: %s\n", add.numero);
         printf("Cidade: %s\n", add.cidade);
         printf("Estado: %s\n", add.estado);
         printf("CEP: %s\n", add.cep);
         printf("Idade: %d\n", add.nascimento);
         printf("Comorbidade: %s\n", add.comorbidade);

     }
     }
     }

     fclose(arquivo);
}


int grupo_sem_risco(){

     system("cls");
     FILE* arquivo; //ponteiro para o arquivo
     cadastro2 add;


     arquivo = fopen("Paciente.txt", "rb"); //abrindo o arquivo com tipo de abertura rb(leitura)
     if(arquivo == NULL){  //testando se o arquivo foi realmente criado
        printf("Problemas na Abertura");

     }
     else {
        fflush(stdin);

     while(fread(&add, sizeof(cadastro2), 1,arquivo)==1){ //fread - L� um arquivo bin�rio
      if(add.nascimento <= 65 && add.confirma >=3){



         printf("\t\t-------GRUPO SEM RISCO-------\t\n");
         printf("\t\t------------------------------\n\n");
         printf("------------------------------------\n");

         printf("Nome: %s\n", add.nome);
         printf("CPF: %s\n", add.cpf);
         printf("Email: %s\n", add.email);
         printf("Fone: %d\n", add.fone);
         printf("Rua: %s\n", add.rua);
         printf("N�mero: %s\n", add.numero);
         printf("Cidade: %s\n", add.cidade);
         printf("Estado: %s\n", add.estado);
         printf("CEP: %s\n", add.cep);
         printf("Idade: %d\n", add.nascimento);

     }
     }
     }

     fclose(arquivo); //fechando o arquivo

}


int login (){

    system("cls");

    char login[20], senha[16];
    int i=0;

    printf("\t\t------LOGIN DO PROGRAMA------\t\t");
    printf("\t\n------------------------------------------------------------\t\n");
    printf("\t\n------------------------------------------------------------\t\n");

    printf("\t LOGIN: ");
    gets(login);
    printf("\n\t SENHA: ");
    gets(senha);

            if(strcmp(usuarios[i].login, login)==0 && strcmp(usuarios[i].senha, senha)==0){
             return 1;
        main();

            }

        else{

        printf("\n\n");
        printf("---------------------------------------------\n");
        printf("| Login incorreto!\7\7 Por favor, tente novamente. |\n");
        printf("---------------------------------------------\n\n");

        }

        system("pause");

        return 0;
}


